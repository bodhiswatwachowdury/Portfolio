import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Users, Target, Award } from 'lucide-react';

const About: React.FC = () => {
  const qualities = [
    {
      icon: Heart,
      title: "Passionate Learner",
      description: "Continuously exploring new technologies and methodologies to stay at the forefront of software development.",
      color: "text-red-500"
    },
    {
      icon: Users,
      title: "Collaborative Professional",
      description: "Strong communication skills and adaptability with a collaborative approach to problem-solving.",
      color: "text-blue-500"
    },
    {
      icon: Target,
      title: "Quality Focused",
      description: "Committed to delivering high-quality solutions that meet and exceed expectations.",
      color: "text-green-500"
    },
    {
      icon: Award,
      title: "Achievement Oriented",
      description: "Driven to accomplish goals and make meaningful contributions to every project.",
      color: "text-purple-500"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            About Me
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            I'm passionate about creating innovative solutions through technology. 
            My journey is driven by curiosity and a desire to make a positive impact 
            through code.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {qualities.map((quality, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6 text-center hover:shadow-2xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
            >
              <motion.div
                className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 mb-4"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <quality.icon className={`w-8 h-8 text-white`} />
              </motion.div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                {quality.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {quality.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">My Mission</h3>
            <p className="text-lg leading-relaxed max-w-4xl mx-auto">
              To leverage technology as a force for positive change, creating solutions that not only 
              solve complex problems but also enhance user experiences and drive business growth. 
              I believe in the power of clean code, thoughtful design, and continuous learning.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;