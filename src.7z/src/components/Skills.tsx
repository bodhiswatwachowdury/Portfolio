import React from 'react';
import { motion } from 'framer-motion';
import { Code, Database, Server, Globe, Terminal, Settings } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      category: "Programming Languages",
      icon: Code,
      skills: [
        { name: "Java", level: 90, color: "bg-orange-500" },
        { name: "Python", level: 85, color: "bg-blue-500" },
        { name: "C", level: 80, color: "bg-gray-600" },
        { name: "SQL", level: 85, color: "bg-purple-500" },
      ]
    },
    {
      category: "Frameworks & Libraries",
      icon: Server,
      skills: [
        { name: "Spring Boot", level: 88, color: "bg-green-500" },
        { name: "Spring Data JPA", level: 82, color: "bg-green-400" },
        { name: "Streamlit", level: 75, color: "bg-red-500" },
      ]
    },
    {
      category: "Databases & Tools",
      icon: Database,
      skills: [
        { name: "MySQL", level: 85, color: "bg-blue-600" },
        { name: "Git", level: 90, color: "bg-orange-600" },
        { name: "GitHub", level: 88, color: "bg-purple-600" },
        { name: "Postman", level: 80, color: "bg-orange-400" },
      ]
    },
    {
      category: "Systems & Concepts",
      icon: Settings,
      skills: [
        { name: "Linux", level: 75, color: "bg-yellow-500" },
        { name: "OOP", level: 90, color: "bg-indigo-500" },
        { name: "Data Structures", level: 85, color: "bg-teal-500" },
        { name: "DBMS", level: 82, color: "bg-purple-600" },
        { name: "OS", level: 78, color: "bg-cyan-500" },
        { name: "Networking", level: 75, color: "bg-pink-500" },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Technical Skills
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            A comprehensive overview of my technical expertise and proficiency levels
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              initial={{ opacity: 0, x: categoryIndex % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: categoryIndex * 0.1 }}
              viewport={{ once: true }}
              className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
            >
              <div className="flex items-center mb-6">
                <motion.div
                  className="p-3 bg-gradient-to-br from-blue-500 to-teal-500 rounded-lg mr-4"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  <category.icon className="w-6 h-6 text-white" />
                </motion.div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {category.category}
                </h3>
              </div>

              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <motion.div
                    key={skillIndex}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: (categoryIndex * 0.1) + (skillIndex * 0.05) }}
                    viewport={{ once: true }}
                    className="relative"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold text-gray-800 dark:text-gray-200">
                        {skill.name}
                      </span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {skill.level}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                      <motion.div
                        className={`h-full ${skill.color} rounded-full relative`}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        transition={{ duration: 1, delay: (categoryIndex * 0.1) + (skillIndex * 0.1) }}
                        viewport={{ once: true }}
                      >
                        <motion.div
                          className="absolute inset-0 bg-white/20 rounded-full"
                          animate={{ x: ['-100%', '100%'] }}
                          transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                        />
                      </motion.div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-full">
            <Terminal className="w-5 h-5" />
            <span className="font-semibold">Always learning and growing!</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;