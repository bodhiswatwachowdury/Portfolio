import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Palette, Star, Award } from 'lucide-react';

const Achievements: React.FC = () => {
  const achievements = [
    {
      title: "National Art Festival",
      category: "Cultural Achievement",
      description: "Participated and showcased artistic skills at national-level art festivals and competitions",
      icon: Trophy,
      color: "from-purple-500 to-indigo-500",
      year: "Recent",
      level: "National Level"
    }
  ];

  return (
    <section id="achievements" className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Achievements & Recognition
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Celebrating artistic accomplishments and creative excellence beyond the realm of technology
          </p>
        </motion.div>

        <div className="grid md:grid-cols-1 gap-8 mb-12 max-w-2xl mx-auto">
          {achievements.map((achievement, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="relative group"
            >
              <div className="bg-gray-50 dark:bg-gray-800 rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 border border-gray-200 dark:border-gray-700 overflow-hidden">
                {/* Background Gradient */}
                <div className={`absolute inset-0 bg-gradient-to-r ${achievement.color} opacity-5 group-hover:opacity-10 transition-opacity duration-300`} />
                
                <div className="relative z-10">
                  {/* Achievement Icon */}
                  <motion.div
                    className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-r ${achievement.color} mb-6 shadow-lg`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ duration: 0.3 }}
                  >
                    <achievement.icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Achievement Details */}
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-3 py-1 bg-gradient-to-r ${achievement.color} text-white text-xs font-semibold rounded-full`}>
                        {achievement.level}
                      </span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {achievement.year}
                      </span>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      {achievement.title}
                    </h3>
                    <p className="text-lg text-blue-600 dark:text-blue-400 font-semibold mb-4">
                      {achievement.category}
                    </p>
                  </div>

                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {achievement.description}
                  </p>

                  {/* Decorative Elements */}
                  <div className="mt-6 flex items-center gap-2">
                    {[...Array(5)].map((_, starIndex) => (
                      <motion.div
                        key={starIndex}
                        initial={{ opacity: 0, scale: 0 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: starIndex * 0.1 }}
                        viewport={{ once: true }}
                      >
                        <Star className={`w-4 h-4 text-yellow-400 fill-current`} />
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Creative Excellence Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 rounded-3xl p-8 text-white relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-4 w-8 h-8 border-2 border-white rounded-full" />
            <div className="absolute top-8 right-8 w-6 h-6 border-2 border-white transform rotate-45" />
            <div className="absolute bottom-4 left-8 w-4 h-4 bg-white rounded-full" />
            <div className="absolute bottom-6 right-6 w-10 h-10 border-2 border-white rounded-full" />
          </div>

          <div className="relative z-10 text-center">
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-2xl mb-6"
              whileHover={{ scale: 1.1, rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <Award className="w-8 h-8 text-white" />
            </motion.div>
            
            <h3 className="text-3xl font-bold mb-4">Creative & Technical Balance</h3>
            <p className="text-lg text-blue-100 leading-relaxed max-w-4xl mx-auto">
              My artistic achievements reflect a well-rounded personality that values creativity alongside technical expertise. 
              This unique combination of analytical thinking and creative expression enhances my approach to software development, 
              bringing innovative solutions and aesthetic sensibility to every project.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Achievements;