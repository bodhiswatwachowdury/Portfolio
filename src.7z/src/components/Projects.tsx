import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, Brain, MessageCircle, Bug } from 'lucide-react';

const Projects: React.FC = () => {
  const projects = [
    {
      title: "AI Movie Recommendation System",
      description: "Advanced content-based filtering system using Python and OpenAI API for personalized movie recommendations with interactive web interface.",
      technologies: ["Python", "Streamlit", "OpenAI API", "Machine Learning"],
      icon: Brain,
      color: "from-purple-500 to-pink-500",
      features: [
        "Content-based filtering algorithm",
        "OpenAI integration for enhanced recommendations",
        "Interactive Streamlit web interface",
        "Real-time movie data processing"
      ]
    },
    {
      title: "Java Chatbot with GPT Integration",
      description: "Intelligent chatbot built with Java Spring Boot framework, featuring GPT integration for natural conversation flow and context awareness.",
      technologies: ["Java", "Spring Boot", "OpenAI API", "REST API"],
      icon: MessageCircle,
      color: "from-blue-500 to-cyan-500",
      features: [
        "Natural language processing",
        "Context-aware conversations",
        "RESTful API architecture",
        "Scalable Spring Boot backend"
      ]
    },
    {
      title: "Bug Tracker System",
      description: "Comprehensive project management and bug tracking system with real-time status updates, user management, and detailed reporting.",
      technologies: ["Java", "Spring Boot", "MySQL", "JPA"],
      icon: Bug,
      color: "from-green-500 to-teal-500",
      features: [
        "Real-time bug tracking",
        "User role management",
        "Status workflow automation",
        "Comprehensive reporting dashboard"
      ]
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Showcasing innovative solutions and technical expertise through real-world applications
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-1 gap-12">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="relative group"
            >
              <div className="bg-gray-50 dark:bg-gray-800 rounded-3xl p-8 hover:shadow-2xl transition-all duration-500 border border-gray-200 dark:border-gray-700 overflow-hidden">
                {/* Background Gradient */}
                <div className={`absolute inset-0 bg-gradient-to-r ${project.color} opacity-5 group-hover:opacity-10 transition-opacity duration-300`} />
                
                <div className="relative z-10 grid lg:grid-cols-3 gap-8 items-center">
                  {/* Project Icon and Title */}
                  <div className="lg:col-span-1">
                    <motion.div
                      className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-r ${project.color} mb-6 shadow-lg`}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <project.icon className="w-10 h-10 text-white" />
                    </motion.div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                      {project.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                      {project.description}
                    </p>
                    
                    {/* Technologies */}
                    <div className="flex flex-wrap gap-2 mb-6">
                      {project.technologies.map((tech, techIndex) => (
                        <motion.span
                          key={techIndex}
                          initial={{ opacity: 0, scale: 0 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: techIndex * 0.1 }}
                          viewport={{ once: true }}
                          className="px-3 py-1 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full text-sm font-medium border border-gray-200 dark:border-gray-600"
                        >
                          {tech}
                        </motion.span>
                      ))}
                    </div>

                    {/* Action Button */}
                    <div className="flex gap-4">
                      <motion.button
                        className="flex items-center gap-2 px-6 py-3 border-2 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-full font-semibold transition-all duration-300"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Github className="w-4 h-4" />
                        Source Code
                      </motion.button>
                    </div>
                  </div>

                  {/* Project Features */}
                  <div className="lg:col-span-2">
                    <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                      Key Features
                    </h4>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {project.features.map((feature, featureIndex) => (
                        <motion.div
                          key={featureIndex}
                          initial={{ opacity: 0, x: 20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.5, delay: featureIndex * 0.1 }}
                          viewport={{ once: true }}
                          className="flex items-start gap-3 p-4 bg-white dark:bg-gray-700 rounded-xl border border-gray-200 dark:border-gray-600 hover:shadow-md transition-all duration-300"
                        >
                          <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${project.color} mt-2 flex-shrink-0`} />
                          <span className="text-gray-700 dark:text-gray-300 leading-relaxed">
                            {feature}
                          </span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;