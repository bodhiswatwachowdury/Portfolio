import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Calendar, Award, BookOpen } from 'lucide-react';

const Education: React.FC = () => {
  const educationData = [
    {
      degree: "Master of Computer Applications (MCA)",
      institution: "RCC Institute of Technology",
      period: "2024 - 2026",
      status: "Currently Pursuing",
      description: "Advanced computer science curriculum focusing on software development, algorithms, and emerging technologies.",
      highlights: [
        "Advanced Software Engineering",
        "Machine Learning & AI",
        "Database Management Systems",
        "Web Technologies"
      ],
      color: "from-blue-600 to-purple-600"
    },
    {
      degree: "Bachelor of Computer Applications (BCA)",
      institution: "Techno Main Salt Lake",
      period: "2021 - 2024",
      status: "Completed",
      grade: "CGPA: 7.57/10",
      description: "Comprehensive foundation in computer science principles, programming, and software development.",
      highlights: [
        "Object-Oriented Programming",
        "Data Structures & Algorithms",
        "Database Management",
        "Software Engineering"
      ],
      color: "from-green-600 to-teal-600"
    }
  ];

  return (
    <section id="education" className="py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Educational Journey
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Building a strong foundation in computer science and continuously expanding knowledge
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-500 to-teal-500 rounded-full hidden lg:block" />

          <div className="space-y-12">
            {educationData.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className={`flex flex-col lg:flex-row items-center gap-8 ${
                  index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                }`}
              >
                {/* Timeline Dot */}
                <motion.div
                  className="hidden lg:flex absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-white dark:bg-gray-900 border-4 border-blue-500 rounded-full z-10"
                  whileHover={{ scale: 1.5 }}
                  transition={{ duration: 0.3 }}
                />

                {/* Content Card */}
                <div className="flex-1 lg:w-1/2">
                  <motion.div
                    className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-200 dark:border-gray-700"
                    whileHover={{ scale: 1.02, y: -5 }}
                    transition={{ duration: 0.3 }}
                  >
                    {/* Header */}
                    <div className="flex items-start gap-4 mb-6">
                      <motion.div
                        className={`p-3 bg-gradient-to-r ${edu.color} rounded-xl`}
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        <GraduationCap className="w-6 h-6 text-white" />
                      </motion.div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                          {edu.degree}
                        </h3>
                        <p className="text-lg text-gray-600 dark:text-gray-300 mb-2">
                          {edu.institution}
                        </p>
                        <div className="flex flex-wrap items-center gap-4 text-sm">
                          <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                            <Calendar className="w-4 h-4" />
                            <span>{edu.period}</span>
                          </div>
                          <div className="flex items-center gap-1 text-green-600 dark:text-green-400">
                            <Award className="w-4 h-4" />
                            <span>{edu.status}</span>
                          </div>
                          {edu.grade && (
                            <div className="flex items-center gap-1 text-purple-600 dark:text-purple-400">
                              <BookOpen className="w-4 h-4" />
                              <span>{edu.grade}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                      {edu.description}
                    </p>

                    {/* Highlights */}
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                        Key Subjects
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                        {edu.highlights.map((highlight, highlightIndex) => (
                          <motion.div
                            key={highlightIndex}
                            initial={{ opacity: 0, scale: 0 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.3, delay: highlightIndex * 0.1 }}
                            viewport={{ once: true }}
                            className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg"
                          >
                            <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${edu.color}`} />
                            <span className="text-sm text-gray-700 dark:text-gray-300">
                              {highlight}
                            </span>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                </div>

                {/* Spacer for alternate layout */}
                <div className="hidden lg:block flex-1 lg:w-1/2" />
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-full">
            <BookOpen className="w-5 h-5" />
            <span className="font-semibold">Lifelong Learning Journey</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Education;